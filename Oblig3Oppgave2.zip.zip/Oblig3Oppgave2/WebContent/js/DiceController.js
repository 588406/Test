"use strict";
class DiceController{
	contructor(root) {
		this.run = this.run.bind(this);
		this.rollDice = this.rollDice.bind(this);

	}
	rollDice(){
		const dice = new Dice();
		dice.rollDice();
		const diceoutput = document.getElementsByName("data-diceoutput")[0];
		diceoutput.innerText = dice.value;
	}
	
	run(){
		const dice = new Dice();
		dice.rollDice();
		
	}
}
	
	const controller = new DiceController("root");	
	document.addEventListener("DOMContentLoaded",controller.run,true);
	const btRef=document.getElementById("button");
	btRef.addEventListener("click",controller.rollDice,true);


	


	