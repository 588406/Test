
"use strict";

class Dice{
	constructor()	{
		this.maxnumber = 6;
		this.value = null;
	}
	
	rollDice()	{
		this.value = 1 + Math.trunc(this.maxnumber*Math.random());
	}

}
